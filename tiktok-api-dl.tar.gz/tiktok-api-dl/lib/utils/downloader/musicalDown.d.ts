import { MusicalDownResponse } from "../../types/downloader/musicaldown";
export declare const MusicalDown: (url: string) => Promise<MusicalDownResponse>;
