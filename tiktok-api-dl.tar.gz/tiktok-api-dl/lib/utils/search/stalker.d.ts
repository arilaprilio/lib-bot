import { StalkResult } from "../../types/search/stalker";
export declare const StalkUser: (username: string, cookie?: any, postLimit?: number) => Promise<StalkResult>;
