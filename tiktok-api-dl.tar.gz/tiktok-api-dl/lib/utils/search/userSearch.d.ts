import { TiktokUserSearchResponse } from "../../types/search/userSearch";
export declare const SearchUser: (username: string, cookie?: any, page?: number) => Promise<TiktokUserSearchResponse>;
